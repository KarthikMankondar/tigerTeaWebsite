# TigerTea

<img src="resources/img/tiger-tea-logo.svg">

### ABOUT
Website selling yummy milktea. See <a href="https://consbulaquena.github.io/TigerTea/">here</a> 

### DONE IN
<ul><li>Html</li>
<li>CSS</li>
<li>JavaScript</li>
</ul>

### I USED
<ul><li>Visual Studio Code</li>
<li>Adobe Photoshop 2020</li>
</ul>
